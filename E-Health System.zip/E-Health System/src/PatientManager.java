import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class PatientManager {
	private ArrayList<Patient> patientList = new ArrayList<Patient>();
	
	public void createPatient(Patient input) throws RemoteException{
		/*
		if((newID+1) > input.getID()) {
			input.setUpdateID(newID+1);
		}*/
		int biggestID = 0;
		int ID=0;
		for ( int i=0; i < patientList.size(); i++) {
			ID = Integer.parseInt(patientList.get(i).getUsername().split(".")[1]);
			if( ID > biggestID) {
				biggestID = Integer.parseInt(patientList.get(i).getUsername().split(".")[1]);
			}
		}
		input.setUsername("user",biggestID+1);
		
		patientList.add(input);
	}
	
	public ArrayList<Patient> createPatient2(Patient input) throws RemoteException{
		/*
		if((newID+1) > input.getID()) {
			input.setUpdateID(newID+1);
		}*/
		int biggestID = 0;
		int ID=0;
		for ( int i=0; i < patientList.size(); i++) {
			ID = Integer.parseInt(patientList.get(i).getUsername().split(".")[1]);
			if( ID > biggestID) {
				biggestID = Integer.parseInt(patientList.get(i).getUsername().split(".")[1]);
			}
		}
		input.setUsername("user",biggestID+1);
		
		patientList.add(input);
		return patientList;
	}
	
	public boolean loginProcess(String username, String password) {
		for(int i=0; i <patientList.size(); i++) {
			if(patientList.get(i).getUsername().contentEquals(username) && patientList.get(i).getPassword().contentEquals(password)) {
				return true;
			}
		}
		return false;
	}
	
	public ArrayList<Patient> getPatients() {
		//JOptionPane.showMessageDialog(null,"Username: "+patientList.get(0).getUsername()+"\nPassword: "+patientList.get(0).getPassword(),"User Credentials!", JOptionPane.DEFAULT_OPTION);
		return patientList;
	}
}
